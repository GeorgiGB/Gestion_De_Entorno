import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'globales.dart' as gbls;

import 'package:menu_lateral/pagina_0.dart';
import 'vistas/creditos.dart';
import 'vistas/pagina_1.dart';
import 'vistas/pagina_2.dart';
import 'vistas/pagina_3.dart';
import 'vistas/pagina_4.dart';
import 'main1.dart' as m1;

void main() {
  // Lanzamos MyApp
  runApp(MyApp());
  //Periodo01224();
}

// Nuestra aplicación es un widget sin estado, que
// contendrá una aplicación MaterialApp

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // modificamos el tooltip text de openAppDrawerTextDelegate para
      // todas las AppBar de la Aplicación
      localizationsDelegates: const [
        gbls.OpenAppDrawerTextDelegate(),
      ],
      debugShowCheckedModeBanner: false, // Eliminamos el banner de "Debug"
      theme: ThemeData(
        // Tema para la aplicación

        fontFamily: 'Roboto', // Fuente por defecto

        textTheme: const TextTheme(
          // Propiedades específicas para los diferentes
          // estilos de texto
          headline5:
              TextStyle(fontWeight: FontWeight.w300, color: Colors.white),
          headline4:
              TextStyle(fontWeight: FontWeight.w400, color: Colors.white),
          headline3:
              TextStyle(fontWeight: FontWeight.w400, color: Colors.white),
          headline2:
              TextStyle(fontWeight: FontWeight.w300, color: Colors.white),
        ),
      ),
      // Establecemos el título de la aplicación y la página Home de ésta
      title: 'Mi App del tiempo',
      initialRoute:
          '/', // Indica la ruta inicial, es decir, la pantalla por defecto
      routes: {
        '/': (context) => const Pagina_0(
            title: 'Login'), // La ruta raíz (/) es la primera pantalla
        '/pagina_1': (context) => const Pagina_1(),
        '/pagina_2': (context) => const Pagina_2(),
        '/pagina_3': (context) => const Pagina_3(),
        '/pagina_4': (context) => const Pagina_4(),
        '/creditos': (context) => const Creditos(),
      },
      //home: const MiAppTiempo(title: 'Mi App del Tiempo'),
    );
  }
}
