import 'package:flutter/material.dart';
import '../Maindrawer.dart';

class Pagina_2 extends StatelessWidget {
  // Widget sin estado con la estructura de la aplicación (abbPar, body, etc.)

  // Constructor
  // El atributo key se usa para identificarlo en el árbol de componentes
  // El atributo title será el título de la barra superior
  const Pagina_2({Key? key}) : super(key: key);
  final String title = "Pagina_2";

  @override
  Widget build(BuildContext context) {
    // Constuctor del widget
    return Scaffold(
        drawer: const MainDrawer(),
        appBar: AppBar(
          title: Text(title),
        ),
        body: OrangeBird() //  Separamos el contenido principal en otro widget
        );
  }
}

class OrangeBird extends StatefulWidget {
  const OrangeBird({Key? key}) : super(key: key);

  @override
  State<OrangeBird> createState() => _OrangeBirdState();
}

class _OrangeBirdState extends State<OrangeBird> {
  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.orange);
  }
}
