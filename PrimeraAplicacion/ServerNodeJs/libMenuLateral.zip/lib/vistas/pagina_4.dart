import 'package:flutter/material.dart';
import '../Maindrawer.dart';

class Pagina_4 extends StatelessWidget {
  // Widget sin estado con la estructura de la aplicación (abbPar, body, etc.)

  // Constructor
  // El atributo key se usa para identificarlo en el árbol de componentes
  // El atributo title será el título de la barra superior
  const Pagina_4({Key? key}) : super(key: key);
  final String title = "Pagina_4s";

  @override
  Widget build(BuildContext context) {
    // Constuctor del widget
    return Scaffold(
        appBar: AppBar(
          title: Text(title),
        ),
        body: BlueBird() //  Separamos el contenido principal en otro widget
        );
  }
}

class BlueBird extends StatefulWidget {
  const BlueBird({Key? key}) : super(key: key);

  @override
  State<BlueBird> createState() => _BlueBirdState();
}

class _BlueBirdState extends State<BlueBird> {
  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.blue);
  }
}
