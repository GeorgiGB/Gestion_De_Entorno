import 'package:flutter/material.dart';
import '../Maindrawer.dart';

class Pagina_1 extends StatelessWidget {
  // Widget sin estado con la estructura de la aplicación (abbPar, body, etc.)

  // Constructor
  // El atributo key se usa para identificarlo en el árbol de componentes
  // El atributo title será el título de la barra superior
  const Pagina_1({Key? key}) : super(key: key);
  final String title = "Pagina 1";

  @override
  Widget build(BuildContext context) {
    // Constuctor del widget
    return Scaffold(
        drawer: const MainDrawer(),
        appBar: AppBar(
          title: Text(title),
        ),
        body: YellowBird() //  Separamos el contenido principal en otro widget
        );
  }
}

class YellowBird extends StatefulWidget {
  const YellowBird({Key? key}) : super(key: key);

  @override
  State<YellowBird> createState() => _YellowBirdState();
}

class _YellowBirdState extends State<YellowBird> {
  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.yellow);
  }
}
