import 'package:flutter/material.dart';
import '../Maindrawer.dart';

class Pagina_3 extends StatelessWidget {
  // Widget sin estado con la estructura de la aplicación (abbPar, body, etc.)

  // Constructor
  // El atributo key se usa para identificarlo en el árbol de componentes
  // El atributo title será el título de la barra superior
  const Pagina_3({Key? key}) : super(key: key);
  final String title = "Pagina_3";

  @override
  Widget build(BuildContext context) {
    // Constuctor del widget
    return Scaffold(
        drawer: const MainDrawer(),
        appBar: AppBar(
          title: Text(title),
        ),
        body: GreeBird() //  Separamos el contenido principal en otro widget
        );
  }
}

class GreeBird extends StatefulWidget {
  const GreeBird({Key? key}) : super(key: key);

  @override
  State<GreeBird> createState() => _GreeBirdState();
}

class _GreeBirdState extends State<GreeBird> {
  final ButtonStyle style =
      ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 20));

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ElevatedButton(
          style: style,
          onPressed: () {
            Navigator.of(context).pushNamed('/pagina_4');
          },
          child: const Text('Enabled'),
        ),
      ],
    );
  }
}
