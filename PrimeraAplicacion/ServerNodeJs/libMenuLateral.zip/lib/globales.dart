library globales;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

// Tomado de // https://medium.com/@caleb_52205/flutter-removing-appbar-tooltips-app-wide-from-materialapp-constructor-54781606266f
// y modificado para openAppDrawerTooltip
// Si miramos dentro de MaterialLocalizations y DefaultMaterialLocalizations
// podemos ver todos los tooltips existentes y si tenemos problemas con
// algun tooltip lo podemos modificar manteniendo la estructura siguiente
class OpenAppDrawerTextOverride extends DefaultMaterialLocalizations {
  OpenAppDrawerTextOverride(Locale locale) : super();
  @override
  String get openAppDrawerTooltip => 'Hola';
}

class OpenAppDrawerTextDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const OpenAppDrawerTextDelegate();
  @override
  Future<OpenAppDrawerTextOverride> load(Locale locale) {
    return SynchronousFuture(OpenAppDrawerTextOverride(locale));
  }

  @override
  bool shouldReload(OpenAppDrawerTextDelegate old) => false;
  @override
  bool isSupported(Locale locale) => true;
}

// ButtonAppDrawer con tooltip adaptado
Builder leadingButtonAppDrawer(String tooltipText) {
  return Builder(
    builder: (BuildContext context) {
      return IconButton(
        icon: const Icon(Icons.menu),
        onPressed: () {
          Scaffold.of(context).openDrawer();
        },
        tooltip: tooltipText,
      );
    },
  );
}
