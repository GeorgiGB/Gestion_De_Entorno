import 'package:flutter/material.dart';

class Pagina_0 extends StatelessWidget {
  // Widget sin estado con la estructura de la aplicación (abbPar, body, etc.)

  // Constructor
  // El atributo key se usa para identificarlo en el árbol de componentes
  // El atributo title será el título de la barra superior
  const Pagina_0({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  Widget build(BuildContext context) {
    // Constuctor del widget
    return Scaffold(
        appBar: AppBar(
          leading: getBackButton(context),
          title: Text(title),
        ),
        body: Login() //  Separamos el contenido principal en otro widget
        );
  }
}

Widget? getBackButton(BuildContext context) {
  return Navigator.canPop(context)
      ? IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        )
      : null;
}

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final ButtonStyle style =
      ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 20));

  @override
  Widget build(BuildContext context) {
    return Column(children: <Widget>[
      Text('Identificarme aparecen los campos para identificarse\n' +
          'Si estoy identificado sólo aparece el botón de cerrar sessión'),
      ElevatedButton(
        style: style,
        onPressed: null,
        child: const Text('Disabled'),
      ),
      const SizedBox(height: 30),
      ElevatedButton(
        style: style,
        onPressed: () {
          Navigator.of(context).pushReplacementNamed('/pagina_1');
        },
        child: const Text('Enabled'),
      ),
    ]);
  }
}
